module.exports = {
  singleQuote: false,
  trailingComma: "none",
  arrowParens: "avoid"
};
